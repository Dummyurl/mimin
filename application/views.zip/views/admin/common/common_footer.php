<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Versi</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2017 <a href="#"> <?php echo $this->lang->line("site_title");?></a>.</strong> All rights reserved.
      </footer>